from netforce.model import Model, fields, get_model
from netforce.utils import get_data_path
import time
from datetime import datetime,timedelta
from decimal import Decimal
from netforce import config
from netforce import database
from netforce.access import get_active_company, set_active_user, set_active_company
from netforce.utils import get_file_path, roundup

class Productlocation(Model):
    _inherit = 'product.location'

Productlocation.register()
