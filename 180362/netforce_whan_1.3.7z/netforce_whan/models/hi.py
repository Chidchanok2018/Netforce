from netforce.model import Model,fields,get_model 
from netforce.utils import get_data_path
import pprint

class hi(Model):
    _name = "testhi"
    _string = "Sheet"
    _fields = {
        "num1":fields.Decimal("Num1"),
        "num2":fields.Decimal("Num2"),
        "num3":fields.Decimal("Result"),
    }

    def onchange_result(self, context={}):
            data = context["data"]
            print(data)
            x = data.get("num1") or 0
            y = data.get("num2") or 0
            data["num3"] = x+y
            return data

    def confirm(self, ids, context={}):
            obj = self.browse(ids)[0]
            x = obj.num1
            y = obj.num2
            obj.write({"num3":(x+y)})

hi.register()

