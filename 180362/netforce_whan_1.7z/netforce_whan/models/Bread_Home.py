from netforce.model import Model, fields, get_model
import pprint

class Breadclass(Model):
    _name = 'bread'
    _string = 'List of Product'
    _fields = {
        "code"      : fields.Char("Code"),
        'des'       : fields.Text('Description'),
        'qty'       : fields.Decimal('Qty'),
        'state'     : fields.Selection([
            ['draft', 'Draft'],
            ['done', 'Completed'],
                                  ],'State'),
        'amount'    : fields.Decimal ('Amount'),
        'total'     : fields.Decimal('Total'),
        "invoice_id": fields.Many2One("account.invoice", "Invoice"),
        'lines'     : fields.One2Many('bread_line', 'order_id', 'lines'),
        }
    _defaults = {
        'state'     : 'draft',
    }

    def onchange_amount(self, context={}):
        data    = context['data']
        qty     = data['qty']
        amount  = data['amount']
        total   = qty + amount
        data['total'] = total
        return data

    def onchange_ref(self, context={}):
        pprint.pprint(context)
        data = context['data']
        print(data)

Breadclass.register()


