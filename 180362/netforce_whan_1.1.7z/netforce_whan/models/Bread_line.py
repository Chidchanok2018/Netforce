from netforce.model import Model, fields, get_model

class breadline(Model):
    _name = "bread_line"
    _string = "Recent Product"
    _fields = {
        "order_id"  : fields.Many2One("bread","bread"),
        "price"     : fields.Integer("Price"),
        'ref'       : fields.Char('Refference'),
        'note'      : fields.Char('Note'),
    }

breadline.register()
