from netforce.model import Model, fields, get_model
import pprint

class MCTest(Model):
    _name = "test"
    _string = "List"
    _fields = {
        "code": fields.Char("Code"),
        "des": fields.Text("Description"),
        "qty": fields.Decimal("Qty"),
        "state": fields.Selection([
            ["draft","Draft"],
            ["done","Completed"],
                                  ],"State"),
        "amount": fields.Decimal("Amount"),
        "total": fields.Decimal("Total"),
        "invoice_id": fields.Many2One("account.invoice", "Invoice"),
        "lines": fields.One2Many("test.line", "order_id", "lines"),
        "num1":fields.Decimal("Num1"),
        "num2":fields.Decimal("Num2"),
        "num3":fields.Decimal("Result"),
        }
    _defaults = {
        "state" : "draft",
    }

    def onchange_amount(self, context={}):
        data = context['data']
        qty = data['qty']
        amount = data['amount']
        total = qty + amount
        data['total'] = total
        return data

    def onchange_ref(self, context={}):
        pprint.pprint(context)
        data = context['data']
        #path = data['path']
        print(data)

    def onchange_result(self, context={}):
        data = context["data"]
        print(data)
        x = data.get("num1") or 0
        y = data.get("num2") or 0
        data["num3"] = x+y

        return data

    def confirm(self, ids, context={}):
        obj = self.browse(ids)[0]
        x = obj.num1
        y = obj.num2
        obj.write( {"num3":(x+y)})

MCTest.register()
