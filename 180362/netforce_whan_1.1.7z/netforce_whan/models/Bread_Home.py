from netforce.model import Model, fields, get_model
import pprint

class Breadclass(Model):
    _name = 'bread'
    _string = 'Product Breads'
    _fields = {
        "code"      : fields.Char("Code", required=True, search=True),
        "name"      : fields.Char("Product Name", required=True, search=True, translate=True, size=256),
        'types'     : fields.Selection([['bar','Bara Birth'],['barr','Barrel'],['blo','Bloomer'],['bat','Batch'],['butt','Buttery Rowies'],['cob','Cob'],['co','Coburg'],['cor','Cornish'],['cot','Cottage'],['farm','Farmhouse'],['pla','Plait']], "Product Type", required=True, search=True),
        'des'       : fields.Text('Description'),
        'qty'       : fields.Decimal('Qty'),
        'state'     : fields.Selection([
            ['draft', 'Draft'],
            ['done', 'Completed'],
                                  ],'State'),
        'amount'    : fields.Decimal ('Amount'),
        'total'     : fields.Decimal('Total'),
        "invoice_id": fields.Many2One("account.invoice", "Invoice"),
        "procure_method": fields.Selection([["mto", "Make To Order"], ["mts", "Make To Stock"]], "Procurement Method"),
        "supply_method": fields.Selection([["purchase", "Purchase"],["production", "Production"]], "Supply Method"),
        "uom_id": fields.Many2One("uom", "Default UoM", required=True),
        'lines'     : fields.One2Many('bread_line', 'order_id', 'lines'),

        "weight": fields.Decimal("Weight (Kg)"),
        "volume": fields.Decimal("Volume (M^3)"),
        "width": fields.Decimal("Width"),
        "height": fields.Decimal("Height"),
        "length": fields.Decimal("Length"),

        "store_type_id": fields.Many2One("store.type", "Storage Type"),
        "shelf_life": fields.Decimal("Shelf Life (Days)"),
        "packing_size": fields.Char("Packing Size"),
        "stock_qty": fields.Decimal("Total Stock Qty",function="get_stock_qty"),

        }
    _defaults = {
        'state'     : 'draft',
    }

    def onchange_amount(self, context={}):
        data    = context['data']
        qty     = data['qty']
        amount  = data['amount']
        total   = qty + amount
        data['total'] = total
        return data

    def onchange_ref(self, context={}):
        pprint.pprint(context)
        data = context['data']
        print(data)

    def get_stock_qty(self,ids,context={}):
            vals={}
            for obj in self.browse(ids):
                qty=0
                for loc in obj.locations:
                    qty+=loc.stock_qty or 0
                    vals[obj.id]=qty
            return vals

Breadclass.register()


