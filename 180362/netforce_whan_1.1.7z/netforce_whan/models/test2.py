from netforce.model import Model, fields, get_model

class test_line(Model):
    _name = "test.line"
    _string = "Test123"
    _fields ={
        "order_id" : fields.Many2One("test","McTest"),
        "price" : fields.Integer("price"),
        "ref": fields.Char("Description"),
        "note": fields.Char("Note"),
       }

test_line.register()
